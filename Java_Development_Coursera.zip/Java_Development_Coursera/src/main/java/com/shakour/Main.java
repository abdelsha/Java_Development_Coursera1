package com.shakour;

import com.shakour.week2dna.stringAssignment;
import com.shakour.week2dna.findGene;
import com.shakour.week2dna.findAbc;
import com.shakour.week2dna.Part1;

public class Main {
    public static void main(String[] args) {
        // This is where you put the week 2 runs
//        stringAssignment dnaseq = new stringAssignment();
//        dnaseq.testSimpleGene();
//        dnaseq.testTwoOccurrences();
//        dnaseq.testLastpart();
//        dnaseq.testfindUrls();

        findGene newDna = new findGene();
        newDna.testFindGene();




//        findAbc st = new findAbc();
//        st.test();

        //Part1 dna = new Part1();




    }
}
